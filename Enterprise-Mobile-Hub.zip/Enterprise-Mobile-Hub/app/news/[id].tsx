import React from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, Platform, Share } from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { type NewsItem } from '@/constants/newsData';

export default function NewsDetailScreen() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams();
  const item: NewsItem = JSON.parse(params.data as string);

  function formatDate(dateStr: string) {
    const date = new Date(dateStr);
    const day = date.getDate();
    const months = ['janeiro', 'fevereiro', 'marco', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
    return `${day} de ${months[date.getMonth()]} de ${date.getFullYear()}`;
  }

  async function handleShare() {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    try {
      await Share.share({
        message: `${item.title}\n\n${item.description}\n\nVia VynorNew's`,
      });
    } catch {}
  }

  return (
    <View style={[styles.container, { paddingTop: Platform.OS === 'web' ? 67 : insets.top }]}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color={Colors.text} />
        </Pressable>
        <Pressable onPress={handleShare} style={styles.shareButton}>
          <Ionicons name="share-outline" size={22} color={Colors.text} />
        </Pressable>
      </View>

      <ScrollView contentContainerStyle={[styles.scrollContent, { paddingBottom: Platform.OS === 'web' ? 34 : insets.bottom + 24 }]} showsVerticalScrollIndicator={false}>
        <View style={styles.metaRow}>
          <View style={styles.sourceBadge}>
            <Text style={styles.sourceText}>{item.source}</Text>
          </View>
          <Text style={styles.dateText}>{formatDate(item.date)}</Text>
        </View>

        <Text style={styles.title}>{item.title}</Text>
        <Text style={styles.subtitle}>{item.subtitle}</Text>

        <View style={styles.readTimeRow}>
          <Ionicons name="time-outline" size={14} color={Colors.textTertiary} />
          <Text style={styles.readTimeText}>{item.readTime} de leitura</Text>
        </View>

        <View style={styles.divider} />

        <Text style={styles.content}>{item.fullContent}</Text>

        <View style={styles.tagRow}>
          <Ionicons name="pricetag-outline" size={14} color={Colors.textTertiary} />
          <Text style={styles.tagText}>Inteligencia de Mercado</Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  backButton: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  shareButton: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scrollContent: {
    paddingHorizontal: 24,
    paddingTop: 8,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 16,
  },
  sourceBadge: {
    backgroundColor: 'rgba(59, 130, 246, 0.12)',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 5,
  },
  sourceText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 12,
    color: Colors.primaryLight,
  },
  dateText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
    color: Colors.textSecondary,
  },
  title: {
    fontFamily: 'Inter_700Bold',
    fontSize: 24,
    color: Colors.text,
    lineHeight: 32,
    marginBottom: 8,
  },
  subtitle: {
    fontFamily: 'Inter_500Medium',
    fontSize: 16,
    color: Colors.accent,
    lineHeight: 22,
    marginBottom: 12,
  },
  readTimeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 16,
  },
  readTimeText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
    color: Colors.textTertiary,
  },
  divider: {
    height: 1,
    backgroundColor: Colors.cardBorder,
    marginBottom: 20,
  },
  content: {
    fontFamily: 'Inter_400Regular',
    fontSize: 15,
    color: Colors.textSecondary,
    lineHeight: 24,
    marginBottom: 24,
  },
  tagRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: Colors.card,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 8,
    alignSelf: 'flex-start',
    borderWidth: 1,
    borderColor: Colors.cardBorder,
  },
  tagText: {
    fontFamily: 'Inter_500Medium',
    fontSize: 12,
    color: Colors.textSecondary,
  },
});
