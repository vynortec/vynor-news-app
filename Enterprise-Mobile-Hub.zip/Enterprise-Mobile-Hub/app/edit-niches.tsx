import React, { useState } from 'react';
import { View, Text, Pressable, StyleSheet, FlatList, Platform } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { useAuth } from '@/contexts/AuthContext';
import { BUSINESS_NICHES } from '@/constants/niches';

export default function EditNichesScreen() {
  const insets = useSafeAreaInsets();
  const { user, updateNiches } = useAuth();
  const [selected, setSelected] = useState<string[]>(user?.selectedNiches || []);

  function toggleNiche(id: string) {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelected(prev =>
      prev.includes(id)
        ? prev.filter(n => n !== id)
        : [...prev, id]
    );
  }

  async function handleSave() {
    if (selected.length < 3) return;
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    await updateNiches(selected);
    router.back();
  }

  function renderItem({ item }: { item: typeof BUSINESS_NICHES[0] }) {
    const isSelected = selected.includes(item.id);
    return (
      <Pressable
        style={[styles.nicheCard, isSelected && styles.nicheCardSelected]}
        onPress={() => toggleNiche(item.id)}
      >
        <View style={[styles.nicheIconContainer, isSelected && styles.nicheIconSelected]}>
          <Ionicons name={item.icon as any} size={22} color={isSelected ? '#FFFFFF' : Colors.textSecondary} />
        </View>
        <Text style={[styles.nicheName, isSelected && styles.nicheNameSelected]} numberOfLines={2}>
          {item.name}
        </Text>
        {isSelected && (
          <View style={styles.checkBadge}>
            <Ionicons name="checkmark" size={12} color="#FFFFFF" />
          </View>
        )}
      </Pressable>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: Platform.OS === 'web' ? 67 : insets.top }]}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color={Colors.text} />
        </Pressable>
        <Text style={styles.headerTitle}>Editar nichos</Text>
        <View style={styles.counterBadge}>
          <Text style={styles.counterText}>{selected.length}</Text>
        </View>
      </View>

      <FlatList
        data={BUSINESS_NICHES}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        numColumns={3}
        contentContainerStyle={styles.grid}
        columnWrapperStyle={styles.row}
        showsVerticalScrollIndicator={false}
        scrollEnabled={!!BUSINESS_NICHES.length}
      />

      <View style={[styles.bottomBar, { paddingBottom: Platform.OS === 'web' ? 34 : insets.bottom + 16 }]}>
        <Pressable
          style={({ pressed }) => [
            styles.saveButton,
            selected.length < 3 && styles.buttonDisabled,
            pressed && selected.length >= 3 && styles.buttonPressed,
          ]}
          onPress={handleSave}
          disabled={selected.length < 3}
        >
          <LinearGradient
            colors={selected.length >= 3 ? ['#1E3A8A', '#3B82F6'] : ['#374151', '#4B5563']}
            style={styles.buttonGradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
          >
            <Ionicons name="checkmark" size={20} color="#FFFFFF" />
            <Text style={styles.saveText}>Salvar alteracoes</Text>
          </LinearGradient>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
  },
  backButton: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    flex: 1,
    fontFamily: 'Inter_600SemiBold',
    fontSize: 18,
    color: Colors.text,
  },
  counterBadge: {
    backgroundColor: Colors.primary,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  counterText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: '#FFFFFF',
  },
  grid: {
    paddingHorizontal: 16,
    paddingTop: 4,
    paddingBottom: 16,
  },
  row: {
    gap: 10,
    marginBottom: 10,
  },
  nicheCard: {
    flex: 1,
    backgroundColor: Colors.card,
    borderRadius: 16,
    padding: 14,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 100,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
    position: 'relative',
  },
  nicheCardSelected: {
    borderColor: Colors.primaryLight,
    backgroundColor: 'rgba(59, 130, 246, 0.08)',
  },
  nicheIconContainer: {
    width: 42,
    height: 42,
    borderRadius: 12,
    backgroundColor: Colors.backgroundTertiary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  nicheIconSelected: {
    backgroundColor: Colors.primary,
  },
  nicheName: {
    fontFamily: 'Inter_500Medium',
    fontSize: 11,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 14,
  },
  nicheNameSelected: {
    color: Colors.text,
  },
  checkBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: Colors.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bottomBar: {
    paddingHorizontal: 24,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: Colors.cardBorder,
    backgroundColor: Colors.background,
  },
  saveButton: {
    borderRadius: 14,
    overflow: 'hidden',
  },
  buttonGradient: {
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 8,
  },
  buttonPressed: {
    opacity: 0.9,
    transform: [{ scale: 0.98 }],
  },
  buttonDisabled: {
    opacity: 0.8,
  },
  saveText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 16,
    color: '#FFFFFF',
  },
});
