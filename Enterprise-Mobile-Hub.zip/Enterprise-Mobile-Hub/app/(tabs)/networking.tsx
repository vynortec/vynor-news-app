import React from 'react';
import { View, Text, StyleSheet, FlatList, Pressable, Platform, Linking } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { EVENTS, type EventItem } from '@/constants/eventsData';

function EventCard({ item }: { item: EventItem }) {
  function formatDate(dateStr: string) {
    const date = new Date(dateStr);
    const day = date.getDate();
    const months = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    return { day: day.toString(), month: months[date.getMonth()] };
  }

  const dateFormatted = formatDate(item.date);
  const isOnline = item.format === 'Online';

  function openLink() {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Linking.openURL(item.link);
  }

  return (
    <View style={styles.eventCard}>
      <View style={styles.eventRow}>
        <View style={styles.dateBox}>
          <Text style={styles.dateDay}>{dateFormatted.day}</Text>
          <Text style={styles.dateMonth}>{dateFormatted.month}</Text>
        </View>
        <View style={styles.eventInfo}>
          <View style={styles.categoryRow}>
            <View style={[styles.formatBadge, isOnline && styles.formatBadgeOnline]}>
              <Ionicons name={isOnline ? 'videocam-outline' : 'location-outline'} size={12} color={isOnline ? Colors.success : Colors.accent} />
              <Text style={[styles.formatText, isOnline && styles.formatTextOnline]}>{item.format}</Text>
            </View>
            <View style={styles.categoryBadge}>
              <Text style={styles.categoryText}>{item.category}</Text>
            </View>
          </View>
          <Text style={styles.eventName} numberOfLines={2}>{item.name}</Text>
          <Text style={styles.eventDescription} numberOfLines={2}>{item.description}</Text>
          <View style={styles.locationRow}>
            <Ionicons name={isOnline ? 'globe-outline' : 'pin-outline'} size={14} color={Colors.textTertiary} />
            <Text style={styles.locationText}>{item.location}</Text>
          </View>
        </View>
      </View>
      <Pressable
        style={({ pressed }) => [styles.inscriptionButton, pressed && { opacity: 0.9 }]}
        onPress={openLink}
      >
        <LinearGradient colors={['#1E3A8A', '#3B82F6']} style={styles.inscriptionGradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
          <Ionicons name="open-outline" size={16} color="#FFFFFF" />
          <Text style={styles.inscriptionText}>Inscrever-se</Text>
        </LinearGradient>
      </Pressable>
    </View>
  );
}

export default function NetworkingScreen() {
  const insets = useSafeAreaInsets();

  function renderHeader() {
    return (
      <View style={styles.headerSection}>
        <Text style={styles.title}>Networking</Text>
        <Text style={styles.subtitle}>Eventos empresariais dos proximos 2 meses</Text>
        <View style={styles.statsBar}>
          <View style={styles.statItem}>
            <Ionicons name="calendar" size={18} color={Colors.primaryLight} />
            <Text style={styles.statValue}>{EVENTS.length}</Text>
            <Text style={styles.statLabel}>Eventos</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.statItem}>
            <Ionicons name="location" size={18} color={Colors.accent} />
            <Text style={styles.statValue}>{EVENTS.filter(e => e.format === 'Presencial').length}</Text>
            <Text style={styles.statLabel}>Presenciais</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.statItem}>
            <Ionicons name="videocam" size={18} color={Colors.success} />
            <Text style={styles.statValue}>{EVENTS.filter(e => e.format === 'Online').length}</Text>
            <Text style={styles.statLabel}>Online</Text>
          </View>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: Platform.OS === 'web' ? 67 : insets.top }]}>
      <FlatList
        data={EVENTS}
        renderItem={({ item }) => <EventCard item={item} />}
        keyExtractor={item => item.id}
        ListHeaderComponent={renderHeader}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        scrollEnabled={!!EVENTS.length}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  listContent: {
    paddingBottom: 120,
  },
  headerSection: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 8,
  },
  title: {
    fontFamily: 'Inter_700Bold',
    fontSize: 26,
    color: Colors.text,
  },
  subtitle: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: Colors.textSecondary,
    marginTop: 4,
    marginBottom: 20,
  },
  statsBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.card,
    borderRadius: 16,
    paddingVertical: 16,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
    marginBottom: 8,
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  statValue: {
    fontFamily: 'Inter_700Bold',
    fontSize: 18,
    color: Colors.text,
  },
  statLabel: {
    fontFamily: 'Inter_400Regular',
    fontSize: 11,
    color: Colors.textSecondary,
  },
  divider: {
    width: 1,
    height: 32,
    backgroundColor: Colors.cardBorder,
  },
  eventCard: {
    backgroundColor: Colors.card,
    marginHorizontal: 20,
    marginTop: 12,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
  },
  eventRow: {
    flexDirection: 'row',
    gap: 14,
    marginBottom: 14,
  },
  dateBox: {
    width: 52,
    height: 58,
    borderRadius: 14,
    backgroundColor: 'rgba(59, 130, 246, 0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(59, 130, 246, 0.2)',
  },
  dateDay: {
    fontFamily: 'Inter_700Bold',
    fontSize: 20,
    color: Colors.primaryLight,
  },
  dateMonth: {
    fontFamily: 'Inter_500Medium',
    fontSize: 11,
    color: Colors.accent,
    textTransform: 'uppercase',
  },
  eventInfo: {
    flex: 1,
    gap: 6,
  },
  categoryRow: {
    flexDirection: 'row',
    gap: 8,
  },
  formatBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(96, 165, 250, 0.1)',
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  formatBadgeOnline: {
    backgroundColor: 'rgba(16, 185, 129, 0.1)',
  },
  formatText: {
    fontFamily: 'Inter_500Medium',
    fontSize: 10,
    color: Colors.accent,
  },
  formatTextOnline: {
    color: Colors.success,
  },
  categoryBadge: {
    backgroundColor: 'rgba(148, 163, 184, 0.1)',
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  categoryText: {
    fontFamily: 'Inter_500Medium',
    fontSize: 10,
    color: Colors.textSecondary,
  },
  eventName: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 15,
    color: Colors.text,
    lineHeight: 20,
  },
  eventDescription: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    color: Colors.textSecondary,
    lineHeight: 17,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 2,
  },
  locationText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    color: Colors.textTertiary,
  },
  inscriptionButton: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  inscriptionGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
  },
  inscriptionText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: '#FFFFFF',
  },
});
