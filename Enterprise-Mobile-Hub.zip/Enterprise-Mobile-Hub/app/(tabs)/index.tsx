import React, { useMemo } from 'react';
import { View, Text, StyleSheet, FlatList, Pressable, Platform, RefreshControl } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import Colors from '@/constants/colors';
import { useAuth } from '@/contexts/AuthContext';
import { generateNewsForNiches, type NewsItem } from '@/constants/newsData';

function NewsCard({ item, index }: { item: NewsItem; index: number }) {
  function formatDate(dateStr: string) {
    const date = new Date(dateStr);
    const day = date.getDate();
    const months = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
    return `${day} ${months[date.getMonth()]}`;
  }

  return (
    <Pressable
      style={({ pressed }) => [styles.newsCard, pressed && { opacity: 0.9 }]}
      onPress={() => router.push({ pathname: '/news/[id]', params: { id: item.id, data: JSON.stringify(item) } })}
    >
      <View style={styles.newsHeader}>
        <View style={styles.sourceRow}>
          <View style={styles.sourceBadge}>
            <Text style={styles.sourceText}>{item.source}</Text>
          </View>
          <Text style={styles.dateText}>{formatDate(item.date)}</Text>
        </View>
        <View style={styles.readTimeBadge}>
          <Ionicons name="time-outline" size={12} color={Colors.textTertiary} />
          <Text style={styles.readTimeText}>{item.readTime}</Text>
        </View>
      </View>

      <Text style={styles.newsTitle} numberOfLines={2}>{item.title}</Text>
      <Text style={styles.newsSubtitle} numberOfLines={1}>{item.subtitle}</Text>
      <Text style={styles.newsDescription} numberOfLines={3}>{item.description}</Text>

      <View style={styles.newsFooter}>
        <View style={styles.readMoreRow}>
          <Text style={styles.readMoreText}>Ler mais</Text>
          <Ionicons name="arrow-forward" size={14} color={Colors.primaryLight} />
        </View>
      </View>
    </Pressable>
  );
}

export default function FeedScreen() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const [refreshing, setRefreshing] = React.useState(false);

  const news = useMemo(() => {
    if (!user?.selectedNiches) return [];
    return generateNewsForNiches(user.selectedNiches);
  }, [user?.selectedNiches]);

  function onRefresh() {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1000);
  }

  function renderHeader() {
    return (
      <View style={styles.headerSection}>
        <View style={styles.greeting}>
          <Text style={styles.greetingText}>Bom dia,</Text>
          <Text style={styles.userName}>{user?.fullName?.split(' ')[0]}</Text>
        </View>
        <View style={styles.statsRow}>
          <LinearGradient colors={['rgba(30, 58, 138, 0.3)', 'rgba(59, 130, 246, 0.1)']} style={styles.statCard} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
            <Ionicons name="newspaper-outline" size={20} color={Colors.primaryLight} />
            <Text style={styles.statNumber}>{news.length}</Text>
            <Text style={styles.statLabel}>Noticias</Text>
          </LinearGradient>
          <LinearGradient colors={['rgba(30, 58, 138, 0.3)', 'rgba(59, 130, 246, 0.1)']} style={styles.statCard} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
            <Ionicons name="layers-outline" size={20} color={Colors.primaryLight} />
            <Text style={styles.statNumber}>{user?.selectedNiches?.length || 0}</Text>
            <Text style={styles.statLabel}>Nichos</Text>
          </LinearGradient>
          <LinearGradient colors={['rgba(30, 58, 138, 0.3)', 'rgba(59, 130, 246, 0.1)']} style={styles.statCard} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
            <Ionicons name="calendar-outline" size={20} color={Colors.primaryLight} />
            <Text style={styles.statNumber}>7</Text>
            <Text style={styles.statLabel}>Dias</Text>
          </LinearGradient>
        </View>
        <Text style={styles.sectionTitle}>Ultimas noticias</Text>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: Platform.OS === 'web' ? 67 : insets.top }]}>
      <FlatList
        data={news}
        renderItem={({ item, index }) => <NewsCard item={item} index={index} />}
        keyExtractor={item => item.id}
        ListHeaderComponent={renderHeader}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.primaryLight} />
        }
        scrollEnabled={!!news.length}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  listContent: {
    paddingBottom: 100,
  },
  headerSection: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 8,
  },
  greeting: {
    marginBottom: 20,
  },
  greetingText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 15,
    color: Colors.textSecondary,
  },
  userName: {
    fontFamily: 'Inter_700Bold',
    fontSize: 26,
    color: Colors.text,
    marginTop: 2,
  },
  statsRow: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    borderRadius: 16,
    padding: 14,
    alignItems: 'center',
    gap: 4,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
  },
  statNumber: {
    fontFamily: 'Inter_700Bold',
    fontSize: 20,
    color: Colors.text,
  },
  statLabel: {
    fontFamily: 'Inter_400Regular',
    fontSize: 11,
    color: Colors.textSecondary,
  },
  sectionTitle: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 18,
    color: Colors.text,
    marginBottom: 4,
  },
  newsCard: {
    backgroundColor: Colors.card,
    marginHorizontal: 20,
    marginTop: 12,
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
  },
  newsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  sourceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  sourceBadge: {
    backgroundColor: 'rgba(59, 130, 246, 0.12)',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  sourceText: {
    fontFamily: 'Inter_500Medium',
    fontSize: 11,
    color: Colors.primaryLight,
  },
  dateText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    color: Colors.textTertiary,
  },
  readTimeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  readTimeText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 11,
    color: Colors.textTertiary,
  },
  newsTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 17,
    color: Colors.text,
    lineHeight: 22,
    marginBottom: 4,
  },
  newsSubtitle: {
    fontFamily: 'Inter_500Medium',
    fontSize: 13,
    color: Colors.accent,
    marginBottom: 8,
  },
  newsDescription: {
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
    color: Colors.textSecondary,
    lineHeight: 19,
    marginBottom: 12,
  },
  newsFooter: {
    borderTopWidth: 1,
    borderTopColor: Colors.cardBorder,
    paddingTop: 12,
  },
  readMoreRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  readMoreText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 13,
    color: Colors.primaryLight,
  },
});
