import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Switch, Pressable, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { useAuth } from '@/contexts/AuthContext';
import { BUSINESS_NICHES } from '@/constants/niches';

export default function AlertsScreen() {
  const insets = useSafeAreaInsets();
  const { user, updateNotificationSettings } = useAuth();
  const [notificationsEnabled, setNotificationsEnabled] = useState(user?.notificationsEnabled ?? true);
  const [frequency, setFrequency] = useState(user?.notificationFrequency ?? 'diaria');

  const selectedNicheNames = BUSINESS_NICHES.filter(n => user?.selectedNiches?.includes(n.id));

  function toggleNotifications(value: boolean) {
    setNotificationsEnabled(value);
    updateNotificationSettings(value, frequency);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  }

  function selectFrequency(freq: string) {
    setFrequency(freq);
    updateNotificationSettings(notificationsEnabled, freq);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  }

  const frequencies = [
    { id: 'tempo_real', label: 'Tempo real', desc: 'Receba alertas assim que publicados', icon: 'flash-outline' },
    { id: 'diaria', label: 'Diaria', desc: 'Um resumo por dia', icon: 'today-outline' },
    { id: 'semanal', label: 'Semanal', desc: 'Um resumo por semana', icon: 'calendar-outline' },
  ];

  return (
    <View style={[styles.container, { paddingTop: Platform.OS === 'web' ? 67 : insets.top }]}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <Text style={styles.title}>Alertas</Text>
        <Text style={styles.subtitle}>Configure suas notificacoes estrategicas</Text>

        <View style={styles.mainToggle}>
          <View style={styles.toggleLeft}>
            <View style={styles.toggleIcon}>
              <Ionicons name="notifications" size={22} color={notificationsEnabled ? Colors.primaryLight : Colors.textTertiary} />
            </View>
            <View>
              <Text style={styles.toggleTitle}>Notificacoes</Text>
              <Text style={styles.toggleDesc}>{notificationsEnabled ? 'Ativadas' : 'Desativadas'}</Text>
            </View>
          </View>
          <Switch
            value={notificationsEnabled}
            onValueChange={toggleNotifications}
            trackColor={{ false: '#374151', true: 'rgba(59, 130, 246, 0.4)' }}
            thumbColor={notificationsEnabled ? Colors.primaryLight : '#6B7280'}
          />
        </View>

        {notificationsEnabled && (
          <>
            <Text style={styles.sectionTitle}>Frequencia</Text>
            <View style={styles.frequencyList}>
              {frequencies.map(freq => (
                <Pressable
                  key={freq.id}
                  style={[styles.frequencyCard, frequency === freq.id && styles.frequencyCardActive]}
                  onPress={() => selectFrequency(freq.id)}
                >
                  <View style={[styles.frequencyIcon, frequency === freq.id && styles.frequencyIconActive]}>
                    <Ionicons name={freq.icon as any} size={20} color={frequency === freq.id ? '#FFFFFF' : Colors.textTertiary} />
                  </View>
                  <View style={styles.frequencyInfo}>
                    <Text style={[styles.frequencyLabel, frequency === freq.id && styles.frequencyLabelActive]}>
                      {freq.label}
                    </Text>
                    <Text style={styles.frequencyDesc}>{freq.desc}</Text>
                  </View>
                  <View style={[styles.radio, frequency === freq.id && styles.radioActive]}>
                    {frequency === freq.id && <View style={styles.radioDot} />}
                  </View>
                </Pressable>
              ))}
            </View>

            <Text style={styles.sectionTitle}>Nichos monitorados</Text>
            <View style={styles.nichesList}>
              {selectedNicheNames.map(niche => (
                <View key={niche.id} style={styles.nicheRow}>
                  <View style={styles.nicheIcon}>
                    <Ionicons name={niche.icon as any} size={18} color={Colors.primaryLight} />
                  </View>
                  <Text style={styles.nicheName}>{niche.name}</Text>
                  <Ionicons name="checkmark-circle" size={18} color={Colors.success} />
                </View>
              ))}
            </View>

            <View style={styles.infoCard}>
              <Ionicons name="information-circle-outline" size={20} color={Colors.accent} />
              <Text style={styles.infoText}>
                As notificacoes serao enviadas com base nos nichos selecionados, priorizando noticias de alto impacto para seu segmento.
              </Text>
            </View>
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 120,
  },
  title: {
    fontFamily: 'Inter_700Bold',
    fontSize: 26,
    color: Colors.text,
  },
  subtitle: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: Colors.textSecondary,
    marginTop: 4,
    marginBottom: 24,
  },
  mainToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: Colors.card,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
    marginBottom: 24,
  },
  toggleLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  toggleIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: Colors.backgroundTertiary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  toggleTitle: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 16,
    color: Colors.text,
  },
  toggleDesc: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  sectionTitle: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 16,
    color: Colors.text,
    marginBottom: 12,
  },
  frequencyList: {
    gap: 10,
    marginBottom: 28,
  },
  frequencyCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.card,
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
    gap: 12,
  },
  frequencyCardActive: {
    borderColor: Colors.primaryLight,
    backgroundColor: 'rgba(59, 130, 246, 0.06)',
  },
  frequencyIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: Colors.backgroundTertiary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  frequencyIconActive: {
    backgroundColor: Colors.primary,
  },
  frequencyInfo: {
    flex: 1,
  },
  frequencyLabel: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: Colors.text,
  },
  frequencyLabelActive: {
    color: Colors.primaryLight,
  },
  frequencyDesc: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  radio: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    borderColor: Colors.textTertiary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioActive: {
    borderColor: Colors.primaryLight,
  },
  radioDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: Colors.primaryLight,
  },
  nichesList: {
    gap: 8,
    marginBottom: 24,
  },
  nicheRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.card,
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
    gap: 12,
  },
  nicheIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: 'rgba(59, 130, 246, 0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  nicheName: {
    flex: 1,
    fontFamily: 'Inter_500Medium',
    fontSize: 14,
    color: Colors.text,
  },
  infoCard: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: 'rgba(59, 130, 246, 0.06)',
    borderRadius: 14,
    padding: 16,
    gap: 10,
    borderWidth: 1,
    borderColor: 'rgba(59, 130, 246, 0.15)',
  },
  infoText: {
    flex: 1,
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
    color: Colors.textSecondary,
    lineHeight: 19,
  },
});
