import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, TextInput, Platform, Linking, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { useAuth } from '@/contexts/AuthContext';

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const { user, updateUser, logout } = useAuth();
  const [editingField, setEditingField] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');
  const [showFAQ, setShowFAQ] = useState(false);

  function startEdit(field: string, currentValue: string) {
    setEditingField(field);
    setEditValue(currentValue);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  }

  function saveEdit() {
    if (!editingField || !editValue.trim()) return;
    const updateData: any = {};
    updateData[editingField] = editValue.trim();
    updateUser(updateData);
    setEditingField(null);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  }

  function handleLogout() {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    logout();
    router.replace('/login');
  }

  function handleWhatsApp() {
    Linking.openURL("https://wa.me/5511999999999?text=Olá,%20preciso%20de%20suporte%20com%20o%20app%20VynorNew's");
  }

  const faqs = [
    { q: 'Como personalizar meu feed?', a: 'Va em Configuracoes > Alterar nichos e selecione os segmentos de interesse.' },
    { q: 'Como funciona o sistema de alertas?', a: 'Os alertas sao baseados nos seus nichos selecionados e priorizados por impacto no segmento.' },
    { q: 'Como cancelar minha conta?', a: 'Entre em contato conosco pelo WhatsApp de suporte no final desta pagina.' },
    { q: 'O que e a aba Networking?', a: 'A aba Networking exibe eventos empresariais relevantes dos proximos 2 meses, com links para inscricao.' },
  ];

  const profileFields = [
    { key: 'fullName', label: 'Nome', value: user?.fullName || '', icon: 'person-outline' },
    { key: 'email', label: 'E-mail', value: user?.email || '', icon: 'mail-outline' },
    { key: 'phone', label: 'Telefone', value: user?.phone || '', icon: 'call-outline' },
  ];

  return (
    <View style={[styles.container, { paddingTop: Platform.OS === 'web' ? 67 : insets.top }]}>
      <ScrollView contentContainerStyle={[styles.scrollContent, { paddingBottom: Platform.OS === 'web' ? 34 + 100 : insets.bottom + 100 }]} showsVerticalScrollIndicator={false}>
        <Text style={styles.title}>Configuracoes</Text>

        <View style={styles.profileHeader}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {user?.fullName?.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase()}
            </Text>
          </View>
          <Text style={styles.profileName}>{user?.fullName}</Text>
          <Text style={styles.profileEmail}>{user?.email}</Text>
        </View>

        <Text style={styles.sectionTitle}>Perfil</Text>
        <View style={styles.section}>
          {profileFields.map((field, idx) => (
            <View key={field.key}>
              {editingField === field.key ? (
                <View style={styles.editRow}>
                  <TextInput
                    style={styles.editInput}
                    value={editValue}
                    onChangeText={setEditValue}
                    autoFocus
                    placeholderTextColor={Colors.textTertiary}
                  />
                  <Pressable onPress={saveEdit} style={styles.saveButton}>
                    <Ionicons name="checkmark" size={20} color={Colors.success} />
                  </Pressable>
                  <Pressable onPress={() => setEditingField(null)} style={styles.cancelButton}>
                    <Ionicons name="close" size={20} color={Colors.danger} />
                  </Pressable>
                </View>
              ) : (
                <Pressable style={styles.settingsRow} onPress={() => startEdit(field.key, field.value)}>
                  <View style={styles.settingsIcon}>
                    <Ionicons name={field.icon as any} size={18} color={Colors.primaryLight} />
                  </View>
                  <View style={styles.settingsInfo}>
                    <Text style={styles.settingsLabel}>{field.label}</Text>
                    <Text style={styles.settingsValue}>{field.value}</Text>
                  </View>
                  <Ionicons name="create-outline" size={18} color={Colors.textTertiary} />
                </Pressable>
              )}
              {idx < profileFields.length - 1 && <View style={styles.separator} />}
            </View>
          ))}
        </View>

        <Text style={styles.sectionTitle}>Preferencias</Text>
        <View style={styles.section}>
          <Pressable style={styles.settingsRow} onPress={() => router.push('/edit-niches')}>
            <View style={styles.settingsIcon}>
              <Ionicons name="layers-outline" size={18} color={Colors.primaryLight} />
            </View>
            <View style={styles.settingsInfo}>
              <Text style={styles.settingsLabel}>Alterar nichos</Text>
              <Text style={styles.settingsValue}>{user?.selectedNiches?.length || 0} selecionados</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={Colors.textTertiary} />
          </Pressable>
          <View style={styles.separator} />
          <Pressable style={styles.settingsRow} onPress={() => router.push('/(tabs)/alerts')}>
            <View style={styles.settingsIcon}>
              <Ionicons name="notifications-outline" size={18} color={Colors.primaryLight} />
            </View>
            <View style={styles.settingsInfo}>
              <Text style={styles.settingsLabel}>Configurar notificacoes</Text>
              <Text style={styles.settingsValue}>{user?.notificationsEnabled ? 'Ativadas' : 'Desativadas'}</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={Colors.textTertiary} />
          </Pressable>
        </View>

        <Text style={styles.sectionTitle}>Conta</Text>
        <View style={styles.section}>
          <Pressable style={styles.settingsRow} onPress={handleLogout}>
            <View style={[styles.settingsIcon, { backgroundColor: 'rgba(245, 158, 11, 0.1)' }]}>
              <Ionicons name="swap-horizontal-outline" size={18} color={Colors.warning} />
            </View>
            <View style={styles.settingsInfo}>
              <Text style={styles.settingsLabel}>Trocar de conta</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={Colors.textTertiary} />
          </Pressable>
          <View style={styles.separator} />
          <Pressable style={styles.settingsRow} onPress={handleLogout}>
            <View style={[styles.settingsIcon, { backgroundColor: 'rgba(239, 68, 68, 0.1)' }]}>
              <Ionicons name="log-out-outline" size={18} color={Colors.danger} />
            </View>
            <View style={styles.settingsInfo}>
              <Text style={[styles.settingsLabel, { color: Colors.danger }]}>Sair da conta</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={Colors.textTertiary} />
          </Pressable>
        </View>

        <Text style={styles.sectionTitle}>Suporte</Text>
        <View style={styles.section}>
          <Pressable style={styles.settingsRow} onPress={handleWhatsApp}>
            <View style={[styles.settingsIcon, { backgroundColor: 'rgba(16, 185, 129, 0.1)' }]}>
              <Ionicons name="logo-whatsapp" size={18} color={Colors.success} />
            </View>
            <View style={styles.settingsInfo}>
              <Text style={styles.settingsLabel}>Suporte via WhatsApp</Text>
            </View>
            <Ionicons name="open-outline" size={16} color={Colors.textTertiary} />
          </Pressable>
          <View style={styles.separator} />
          <Pressable style={styles.settingsRow} onPress={() => { setShowFAQ(!showFAQ); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}>
            <View style={styles.settingsIcon}>
              <Ionicons name="help-circle-outline" size={18} color={Colors.primaryLight} />
            </View>
            <View style={styles.settingsInfo}>
              <Text style={styles.settingsLabel}>FAQ</Text>
            </View>
            <Ionicons name={showFAQ ? 'chevron-up' : 'chevron-down'} size={18} color={Colors.textTertiary} />
          </Pressable>
        </View>

        {showFAQ && (
          <View style={styles.faqSection}>
            {faqs.map((faq, idx) => (
              <View key={idx} style={styles.faqItem}>
                <Text style={styles.faqQuestion}>{faq.q}</Text>
                <Text style={styles.faqAnswer}>{faq.a}</Text>
              </View>
            ))}
          </View>
        )}

        <Text style={styles.versionText}>VynorNew's v1.0.0</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 16,
  },
  title: {
    fontFamily: 'Inter_700Bold',
    fontSize: 26,
    color: Colors.text,
    marginBottom: 20,
  },
  profileHeader: {
    alignItems: 'center',
    marginBottom: 28,
  },
  avatar: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  avatarText: {
    fontFamily: 'Inter_700Bold',
    fontSize: 24,
    color: '#FFFFFF',
  },
  profileName: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 18,
    color: Colors.text,
  },
  profileEmail: {
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  sectionTitle: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: Colors.textTertiary,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: 8,
    marginTop: 4,
  },
  section: {
    backgroundColor: Colors.card,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
    marginBottom: 20,
    overflow: 'hidden',
  },
  settingsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    gap: 12,
  },
  settingsIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: 'rgba(59, 130, 246, 0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  settingsInfo: {
    flex: 1,
  },
  settingsLabel: {
    fontFamily: 'Inter_500Medium',
    fontSize: 15,
    color: Colors.text,
  },
  settingsValue: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    color: Colors.textSecondary,
    marginTop: 1,
  },
  separator: {
    height: 1,
    backgroundColor: Colors.cardBorder,
    marginLeft: 62,
  },
  editRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    gap: 8,
  },
  editInput: {
    flex: 1,
    fontFamily: 'Inter_400Regular',
    fontSize: 15,
    color: Colors.text,
    backgroundColor: Colors.inputBackground,
    borderRadius: 10,
    padding: 12,
    borderWidth: 1,
    borderColor: Colors.primaryLight,
  },
  saveButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cancelButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  faqSection: {
    gap: 12,
    marginBottom: 20,
  },
  faqItem: {
    backgroundColor: Colors.card,
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
  },
  faqQuestion: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: Colors.text,
    marginBottom: 6,
  },
  faqAnswer: {
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
    color: Colors.textSecondary,
    lineHeight: 19,
  },
  versionText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    color: Colors.textTertiary,
    textAlign: 'center',
    marginTop: 8,
    marginBottom: 16,
  },
});
