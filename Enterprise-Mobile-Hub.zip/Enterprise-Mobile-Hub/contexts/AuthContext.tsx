import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface UserData {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  selectedNiches: string[];
  notificationsEnabled: boolean;
  notificationFrequency: string;
}

interface AuthContextValue {
  user: UserData | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  hasSelectedNiches: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (data: { fullName: string; email: string; phone: string; password: string }) => Promise<boolean>;
  logout: () => Promise<void>;
  updateUser: (data: Partial<UserData>) => Promise<void>;
  updateNiches: (niches: string[]) => Promise<void>;
  updateNotificationSettings: (enabled: boolean, frequency: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadUser();
  }, []);

  async function loadUser() {
    try {
      const userData = await AsyncStorage.getItem('@vynortec_user');
      if (userData) {
        setUser(JSON.parse(userData));
      }
    } catch (e) {
      console.error('Error loading user:', e);
    } finally {
      setIsLoading(false);
    }
  }

  async function saveUser(userData: UserData) {
    await AsyncStorage.setItem('@vynortec_user', JSON.stringify(userData));
    setUser(userData);
  }

  async function login(email: string, password: string): Promise<boolean> {
    try {
      const usersData = await AsyncStorage.getItem('@vynortec_users');
      const users: Array<UserData & { password: string }> = usersData ? JSON.parse(usersData) : [];
      const found = users.find(u => u.email === email && u.password === password);
      if (found) {
        const { password: _, ...userData } = found;
        await saveUser(userData);
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }

  async function register(data: { fullName: string; email: string; phone: string; password: string }): Promise<boolean> {
    try {
      const usersData = await AsyncStorage.getItem('@vynortec_users');
      const users: Array<UserData & { password: string }> = usersData ? JSON.parse(usersData) : [];

      if (users.find(u => u.email === data.email)) {
        return false;
      }

      const newUser = {
        id: Date.now().toString(),
        fullName: data.fullName,
        email: data.email,
        phone: data.phone,
        password: data.password,
        selectedNiches: [],
        notificationsEnabled: true,
        notificationFrequency: 'diaria',
      };

      users.push(newUser);
      await AsyncStorage.setItem('@vynortec_users', JSON.stringify(users));

      const { password: _, ...userData } = newUser;
      await saveUser(userData);
      return true;
    } catch {
      return false;
    }
  }

  async function logout() {
    await AsyncStorage.removeItem('@vynortec_user');
    setUser(null);
  }

  async function updateUser(data: Partial<UserData>) {
    if (!user) return;
    const updated = { ...user, ...data };
    await saveUser(updated);

    const usersData = await AsyncStorage.getItem('@vynortec_users');
    if (usersData) {
      const users = JSON.parse(usersData);
      const idx = users.findIndex((u: any) => u.id === user.id);
      if (idx >= 0) {
        users[idx] = { ...users[idx], ...data };
        await AsyncStorage.setItem('@vynortec_users', JSON.stringify(users));
      }
    }
  }

  async function updateNiches(niches: string[]) {
    await updateUser({ selectedNiches: niches });
  }

  async function updateNotificationSettings(enabled: boolean, frequency: string) {
    await updateUser({ notificationsEnabled: enabled, notificationFrequency: frequency });
  }

  const value = useMemo(() => ({
    user,
    isLoading,
    isAuthenticated: !!user,
    hasSelectedNiches: !!user && user.selectedNiches.length > 0,
    login,
    register,
    logout,
    updateUser,
    updateNiches,
    updateNotificationSettings,
  }), [user, isLoading]);

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
