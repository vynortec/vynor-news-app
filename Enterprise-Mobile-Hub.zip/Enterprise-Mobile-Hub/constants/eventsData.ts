export interface EventItem {
  id: string;
  name: string;
  description: string;
  date: string;
  location: string;
  format: string;
  link: string;
  category: string;
}

export const EVENTS: EventItem[] = [
  {
    id: 'e1',
    name: 'Web Summit Rio 2025',
    description: 'O maior evento de tecnologia e inovacao da America Latina, reunindo liderancas globais, investidores e startups para tres dias de palestras, networking e conexoes estrategicas.',
    date: '2025-04-14',
    location: 'Rio de Janeiro, RJ',
    format: 'Presencial',
    link: 'https://rio.websummit.com',
    category: 'Tecnologia',
  },
  {
    id: 'e2',
    name: 'VTEX Day 2025',
    description: 'Principal evento de comercio digital da America Latina, com foco em inovacao no e-commerce, cases de sucesso e tendencias de mercado para o varejo digital.',
    date: '2025-04-08',
    location: 'Sao Paulo, SP',
    format: 'Presencial',
    link: 'https://vtexday.vtex.com',
    category: 'E-commerce',
  },
  {
    id: 'e3',
    name: 'Startup Summit 2025',
    description: 'Evento focado em empreendedorismo e inovacao, conectando startups a investidores, mentores e grandes corporacoes em busca de parcerias estrategicas.',
    date: '2025-03-25',
    location: 'Florianopolis, SC',
    format: 'Presencial',
    link: 'https://www.startupsummit.com.br',
    category: 'Startups',
  },
  {
    id: 'e4',
    name: 'Masterclass: Financas para Empreendedores',
    description: 'Workshop online intensivo sobre gestao financeira empresarial, incluindo fluxo de caixa, planejamento tributario e estrategias de financiamento para PMEs.',
    date: '2025-03-10',
    location: 'Online',
    format: 'Online',
    link: 'https://www.sebrae.com.br/sites/PortalSebrae/cursosonline',
    category: 'Financas',
  },
  {
    id: 'e5',
    name: 'ABF Expo Franchising 2025',
    description: 'Maior feira de franquias do mundo, apresentando mais de 400 marcas franqueadoras, seminarios sobre tendencias do setor e oportunidades de investimento.',
    date: '2025-03-19',
    location: 'Sao Paulo, SP',
    format: 'Presencial',
    link: 'https://www.abfexpo.com.br',
    category: 'Franquias',
  },
  {
    id: 'e6',
    name: 'Mentoria Coletiva: Escala Digital',
    description: 'Sessao de mentoria com empreendedores de sucesso sobre estrategias de escala digital, growth hacking e monetizacao de plataformas online.',
    date: '2025-03-05',
    location: 'Online',
    format: 'Online',
    link: 'https://endeavor.org.br/eventos',
    category: 'Marketing Digital',
  },
  {
    id: 'e7',
    name: 'Agrishow 2025',
    description: 'Maior feira de tecnologia agricola da America Latina, com exposicao de maquinarios, solucoes de precisao, drones e inovacoes para o agronegocio.',
    date: '2025-04-28',
    location: 'Ribeirao Preto, SP',
    format: 'Presencial',
    link: 'https://www.agrishow.com.br',
    category: 'Agronegocio',
  },
  {
    id: 'e8',
    name: 'Workshop: IA Aplicada aos Negocios',
    description: 'Workshop pratico sobre implementacao de inteligencia artificial em processos empresariais, com demonstracoes de ferramentas e cases de sucesso brasileiros.',
    date: '2025-03-15',
    location: 'Online',
    format: 'Online',
    link: 'https://www.startse.com/eventos',
    category: 'Inteligencia Artificial',
  },
  {
    id: 'e9',
    name: 'Febraban Tech 2025',
    description: 'Principal evento de tecnologia financeira do Brasil, reunindo bancos, fintechs e empresas de tecnologia para debater o futuro do setor financeiro.',
    date: '2025-04-02',
    location: 'Sao Paulo, SP',
    format: 'Presencial',
    link: 'https://febrabantech.febraban.org.br',
    category: 'Fintech',
  },
  {
    id: 'e10',
    name: 'Encontro Nacional de Empreendedores',
    description: 'Encontro presencial com paineis sobre tendencias de mercado, networking qualificado e acesso a oportunidades de negocio em diversos setores da economia.',
    date: '2025-03-28',
    location: 'Brasilia, DF',
    format: 'Presencial',
    link: 'https://www.sebrae.com.br/sites/PortalSebrae/ufs/df',
    category: 'Networking',
  },
];
