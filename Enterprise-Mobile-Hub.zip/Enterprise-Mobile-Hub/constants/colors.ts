const Colors = {
  background: '#000000',
  backgroundSecondary: '#0A0E1A',
  backgroundTertiary: '#111827',
  card: '#0F1629',
  cardBorder: '#1A2542',
  primary: '#1E3A8A',
  primaryLight: '#3B82F6',
  accent: '#60A5FA',
  text: '#FFFFFF',
  textSecondary: '#94A3B8',
  textTertiary: '#64748B',
  inputBackground: '#111827',
  inputBorder: '#1E293B',
  danger: '#EF4444',
  success: '#10B981',
  warning: '#F59E0B',
  tabBar: '#050A15',
  tabBarBorder: '#1A2542',
  light: {
    text: '#FFFFFF',
    background: '#000000',
    tint: '#3B82F6',
    tabIconDefault: '#64748B',
    tabIconSelected: '#3B82F6',
  },
};

export default Colors;
